--
-- PostgreSQL database dump
--

\restrict C3hadsvVZSKudQvxIFAJOJ68ROA3t3F671NJWCAQrD5OordqMIWuJIISkNy9Xmv

-- Dumped from database version 18.4 (Debian 18.4-1.pgdg13+1)
-- Dumped by pg_dump version 18.4 (Debian 18.4-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: cleanup_sync_log(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cleanup_sync_log(retention_days integer DEFAULT 60) RETURNS TABLE(deleted_count bigint, cutoff_timestamp timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE
    cutoff TIMESTAMPTZ;
    rows_deleted BIGINT;
BEGIN
    cutoff := now() - (retention_days || ' days')::INTERVAL;

    DELETE FROM sync_log
    WHERE COALESCE(finished_at, started_at) < cutoff;

    GET DIAGNOSTICS rows_deleted = ROW_COUNT;

    RETURN QUERY SELECT rows_deleted, cutoff;
END;
$$;


ALTER FUNCTION public.cleanup_sync_log(retention_days integer) OWNER TO postgres;

--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.touch_updated_at() OWNER TO postgres;

--
-- Name: trg_sync_log_retention_fn(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_sync_log_retention_fn() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    rows_deleted BIGINT;
BEGIN
    DELETE FROM sync_log
    WHERE COALESCE(finished_at, started_at) < now() - INTERVAL '60 days';
    GET DIAGNOSTICS rows_deleted = ROW_COUNT;
    IF rows_deleted > 0 THEN
        RAISE NOTICE '[sync_log retention] cleaned % old row(s)', rows_deleted;
    END IF;
    RETURN NULL;  -- AFTER STATEMENT trigger 忽略返回值
END;
$$;


ALTER FUNCTION public.trg_sync_log_retention_fn() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: analytics_audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_audit_log (
    id bigint NOT NULL,
    request_id text,
    endpoint text NOT NULL,
    method text NOT NULL,
    path text NOT NULL,
    status integer NOT NULL,
    key_prefix text,
    records_in integer,
    records_ok integer,
    records_rej integer,
    error_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.analytics_audit_log OWNER TO postgres;

--
-- Name: analytics_cursors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_cursors (
    seller_id text NOT NULL,
    advertiser_id text NOT NULL,
    storage_key text NOT NULL,
    campaign_id text NOT NULL,
    latest_completed_day date,
    last_updated_at timestamp with time zone DEFAULT now() NOT NULL,
    request_id text,
    CONSTRAINT ck_analytics_cursors_storage CHECK ((storage_key = ANY (ARRAY['productAnalyses'::text, 'sessionAnalyses'::text, 'campaignChangeLogs'::text])))
);


ALTER TABLE public.analytics_cursors OWNER TO postgres;

--
-- Name: analytics_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_records (
    id bigint NOT NULL,
    idempotency_key text NOT NULL,
    source_record_id text,
    seller_id text NOT NULL,
    advertiser_id text NOT NULL,
    storage_key text NOT NULL,
    campaign_id text NOT NULL,
    day date NOT NULL,
    page integer NOT NULL,
    shop_name text,
    endpoint text NOT NULL,
    method text NOT NULL,
    request_body jsonb,
    response_data jsonb NOT NULL,
    source text NOT NULL,
    captured_at timestamp with time zone NOT NULL,
    schema_version integer DEFAULT 1 NOT NULL,
    protocol_version integer DEFAULT 1 NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    request_id text,
    CONSTRAINT ck_analytics_records_page CHECK ((page > 0)),
    CONSTRAINT ck_analytics_records_protocol CHECK ((protocol_version > 0)),
    CONSTRAINT ck_analytics_records_schema CHECK ((schema_version > 0)),
    CONSTRAINT ck_analytics_records_storage CHECK ((storage_key = ANY (ARRAY['productAnalyses'::text, 'sessionAnalyses'::text, 'campaignChangeLogs'::text])))
);


ALTER TABLE public.analytics_records OWNER TO postgres;

--
-- Name: analytics_shop_timezones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_shop_timezones (
    seller_id text NOT NULL,
    advertiser_id text NOT NULL,
    timezone text DEFAULT 'Asia/Shanghai'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.analytics_shop_timezones OWNER TO postgres;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_keys (
    id bigint NOT NULL,
    key_hash text NOT NULL,
    key_prefix text NOT NULL,
    name text NOT NULL,
    role text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    scopes text[] DEFAULT ARRAY[]::text[] NOT NULL,
    CONSTRAINT api_keys_role_check CHECK ((role = ANY (ARRAY['readonly'::text, 'readwrite'::text, 'admin'::text])))
);


ALTER TABLE public.api_keys OWNER TO postgres;

--
-- Name: cancellations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cancellations (
    cancel_id text NOT NULL,
    shop_id text,
    order_id text,
    cancel_status text,
    cancel_reason text,
    cancel_reason_text text,
    cancel_type text,
    role text,
    should_replenish_stock boolean,
    create_time bigint,
    update_time bigint,
    raw jsonb NOT NULL,
    synced_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cancellations OWNER TO postgres;

--
-- Name: logistics_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logistics_events (
    id bigint NOT NULL,
    order_id text NOT NULL,
    action_code integer,
    event_time timestamp with time zone,
    location text,
    description text,
    raw jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.logistics_events OWNER TO postgres;

--
-- Name: logistics_sync_targets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logistics_sync_targets (
    order_id text NOT NULL,
    shop_id text NOT NULL,
    last_synced_at timestamp with time zone,
    last_n_events integer,
    needs_resync boolean DEFAULT true NOT NULL
);


ALTER TABLE public.logistics_sync_targets OWNER TO postgres;

--
-- Name: logistics_tracking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logistics_tracking (
    order_id text NOT NULL,
    shop_id text,
    tracking_number text,
    n_events integer DEFAULT 0 NOT NULL,
    first_event_at bigint,
    last_event_at bigint,
    last_action_code integer,
    last_description text,
    final_status text,
    arrived_overseas boolean DEFAULT false NOT NULL,
    arrived_at bigint,
    origin_departed_at bigint,
    import_cleared_at bigint,
    delivered_at bigint,
    returned_at bigint,
    raw jsonb NOT NULL,
    synced_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.logistics_tracking OWNER TO postgres;

--
-- Name: logistics_tracking_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logistics_tracking_events (
    order_id text NOT NULL,
    action_code integer NOT NULL,
    event_time bigint NOT NULL,
    description text,
    location text,
    synced_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.logistics_tracking_events OWNER TO postgres;

--
-- Name: miaoshou_collect_box_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.miaoshou_collect_box_details (
    platform text NOT NULL,
    common_collect_box_detail_id bigint CONSTRAINT miaoshou_collect_box_detail_common_collect_box_detail__not_null NOT NULL,
    app_account_id bigint,
    sub_app_account_id bigint,
    item_num text,
    title text,
    thumbnail text,
    list_thumbnail text,
    price numeric,
    min_sku_price numeric,
    max_sku_price numeric,
    stock integer,
    remark text,
    status text,
    reason text,
    gmt_create text,
    gmt_modified text,
    weight numeric,
    max_sku_weight numeric,
    min_sku_weight numeric,
    common_collect_box_group_id bigint,
    common_collect_box_group_name text,
    owner_sub_account_alias_name text,
    is_mark text,
    is_cb integer,
    is_cnsc integer,
    raw_json jsonb,
    synced_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.miaoshou_collect_box_details OWNER TO postgres;

--
-- Name: miaoshou_move_collect_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.miaoshou_move_collect_tasks (
    platform text NOT NULL,
    move_collect_task_detail_id text CONSTRAINT miaoshou_move_collect_tasks_move_collect_task_detail_i_not_null NOT NULL,
    collect_box_detail_id text,
    shop_id text,
    item_num text,
    cid text,
    source text,
    source_site text,
    source_item_id text,
    title text,
    thumbnail text,
    is_timing text,
    status text,
    reason text,
    gmt_create text,
    gmt_modified text,
    platform_item_id text,
    is_renew_item boolean,
    shop_name text,
    site_name text,
    site text,
    source_item_url text,
    item_edit_url text,
    breadcrumb text,
    owner_sub_app_account_id bigint,
    owner_sub_account_alias_name text,
    raw_json jsonb,
    synced_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.miaoshou_move_collect_tasks OWNER TO postgres;

--
-- Name: miaoshou_price_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.miaoshou_price_templates (
    price_template_id bigint NOT NULL,
    app_account_id bigint,
    sub_app_account_id bigint,
    platform text,
    site text,
    name text,
    remark text,
    currency text,
    display_weight_unit text,
    profit_type text,
    profit_percent numeric,
    fixed_profit_amount numeric,
    exchange_rate numeric,
    discount numeric,
    price_tail_compute_type text,
    price_tail text,
    price_process_decimal_type text,
    logistics_compute_type text,
    weight_ref_type text,
    first_weight_charge numeric,
    first_weight_interval numeric,
    continued_weight_charge numeric,
    continued_weight_interval numeric,
    logistics_charge numeric,
    platform_charge_percent numeric,
    payment_charge_percent numeric,
    activity_charge_percent numeric,
    withdraw_charge_percent numeric,
    other_charge numeric,
    is_cal_light_cargo integer,
    light_cargo_coefficient integer,
    weight_logistics_charge_list text,
    domestic_logistics_compute_type text,
    domestic_logistics_first_weight_charge numeric,
    domestic_logistics_first_weight_interval numeric,
    domestic_logistics_continued_weight_charge numeric,
    domestic_logistics_continued_weight_interval numeric,
    domestic_logistics_charge numeric,
    buyer_logistic_charge numeric,
    seller_logistic_charge numeric,
    has_seller_logistic_charge integer,
    official_tpl_mode text,
    official_tpl_logistics_channel text,
    snapshot_id bigint,
    gmt_create text,
    gmt_modified text,
    raw_json jsonb,
    synced_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.miaoshou_price_templates OWNER TO postgres;

--
-- Name: miaoshou_shops; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.miaoshou_shops (
    shop_id bigint NOT NULL,
    platform text NOT NULL,
    site text NOT NULL,
    platform_shop_name text,
    shop_nick text,
    parent_shop_id bigint,
    is_cb integer,
    is_cnsc integer,
    status text,
    gmt_expire text,
    gmt_last_auth text,
    raw_json jsonb,
    synced_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.miaoshou_shops OWNER TO postgres;

--
-- Name: oauth_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_tokens (
    id bigint NOT NULL,
    shop_id text NOT NULL,
    provider text DEFAULT 'tiktok'::text NOT NULL,
    access_token_encrypted bytea NOT NULL,
    refresh_token_encrypted bytea NOT NULL,
    shop_cipher_encrypted bytea,
    shop_name text,
    shop_region text,
    seller_type text,
    access_token_expires_at bigint,
    refresh_token_expires_at bigint,
    granted_scopes text[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone,
    last_refresh_at timestamp with time zone
);


ALTER TABLE public.oauth_tokens OWNER TO postgres;

--
-- Name: TABLE oauth_tokens; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.oauth_tokens IS 'OAuth token storage for the oauth-receiver service. Sensitive columns (access_token, refresh_token, shop_cipher) are encrypted with Fernet; key loaded from OAUTH_DB_ENCRYPTION_KEY env var.';


--
-- Name: COLUMN oauth_tokens.shop_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.oauth_tokens.shop_id IS 'TikTok Shop id (or other provider-specific shop identifier). Used for isolation — each shop has its own row.';


--
-- Name: COLUMN oauth_tokens.access_token_encrypted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.oauth_tokens.access_token_encrypted IS 'Fernet-encrypted OAuth access_token. Decrypt with the same key to use.';


--
-- Name: COLUMN oauth_tokens.refresh_token_encrypted; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.oauth_tokens.refresh_token_encrypted IS 'Fernet-encrypted OAuth refresh_token. Use to mint new access_token when current one expires.';


--
-- Name: oauth_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.oauth_tokens_id_seq OWNER TO postgres;

--
-- Name: oauth_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_tokens_id_seq OWNED BY public.oauth_tokens.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    order_id text NOT NULL,
    item_id text NOT NULL,
    shop_id text,
    sku_id text,
    product_id text,
    product_name text,
    sku_name text,
    sku_image text,
    quantity integer,
    sku_price numeric(18,2),
    raw jsonb NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: order_shippings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_shippings (
    order_id text NOT NULL,
    shop_id text,
    tracking_number text,
    shipping_provider_id text,
    shipping_provider_name text,
    raw jsonb NOT NULL,
    synced_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.order_shippings OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    order_id text NOT NULL,
    shop_id text NOT NULL,
    order_status_name text,
    payment_amount numeric(18,2),
    payment_currency text,
    total_amount numeric(18,2),
    buyer_email text,
    buyer_message text,
    create_time bigint,
    update_time bigint,
    paid_time bigint,
    shipped_time bigint,
    delivered_time bigint,
    cancelled_time bigint,
    fulfillment_type text,
    raw jsonb NOT NULL,
    synced_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    payment_id text NOT NULL,
    shop_id text,
    status text,
    currency text,
    amount_value numeric(18,2),
    settlement_amount_value numeric(18,2),
    payment_amount_before_value numeric(18,2),
    reserve_amount_value numeric(18,2),
    exchange_rate text,
    bank_account text,
    create_time bigint,
    paid_time bigint,
    raw jsonb NOT NULL,
    synced_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: returns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.returns (
    return_id text NOT NULL,
    shop_id text,
    order_id text,
    return_status text,
    return_reason text,
    return_type text,
    role text,
    create_time bigint,
    update_time bigint,
    raw jsonb NOT NULL,
    synced_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.returns OWNER TO postgres;

--
-- Name: shops; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shops (
    shop_id text NOT NULL,
    shop_name text,
    shop_region text,
    shop_cipher text,
    seller_type text,
    last_seen_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.shops OWNER TO postgres;

--
-- Name: statement_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.statement_transactions (
    txn_id text NOT NULL,
    statement_id text NOT NULL,
    shop_id text,
    order_id text,
    order_create_time bigint,
    type text,
    currency text,
    actual_return_shipping_fee_amount numeric(18,2),
    actual_shipping_fee_amount numeric(18,2),
    adjustment_amount numeric(18,2),
    affiliate_ads_commission_amount numeric(18,2),
    affiliate_commission_amount numeric(18,2),
    affiliate_commission_before_pit numeric(18,2),
    affiliate_partner_commission_amount numeric(18,2),
    after_seller_discounts_subtotal_amount numeric(18,2),
    customer_order_refund_amount numeric(18,2),
    customer_paid_shipping_fee_amount numeric(18,2),
    customer_paid_shipping_fee_refund_amount numeric(18,2),
    customer_payment_amount numeric(18,2),
    customer_refund_amount numeric(18,2),
    customer_shipping_fee_amount numeric(18,2),
    customer_shipping_fee_offset_amount numeric(18,2),
    fbm_shipping_cost_amount numeric(18,2),
    fbt_fulfillment_fee_amount numeric(18,2),
    fbt_fulfillment_fee_reimbursement_amount numeric(18,2),
    fbt_shipping_cost_amount numeric(18,2),
    fee_amount numeric(18,2),
    gross_sales_amount numeric(18,2),
    gross_sales_refund_amount numeric(18,2),
    isr_income_tax_amount numeric(18,2),
    iva_vat_amount numeric(18,2),
    net_sales_amount numeric(18,2),
    pit_amount numeric(18,2),
    platform_commission_amount numeric(18,2),
    platform_discount_amount numeric(18,2),
    platform_discount_refund_amount numeric(18,2),
    platform_refund_subsidy_amount numeric(18,2),
    platform_shipping_fee_discount_amount numeric(18,2),
    promo_shipping_incentive_amount numeric(18,2),
    referral_fee_amount numeric(18,2),
    refund_administration_fee_amount numeric(18,2),
    refund_shipping_cost_discount_amount numeric(18,2),
    retail_delivery_fee_amount numeric(18,2),
    retail_delivery_fee_payment_amount numeric(18,2),
    retail_delivery_fee_refund_amount numeric(18,2),
    return_shipping_fee_amount numeric(18,2),
    revenue_amount numeric(18,2),
    sales_tax_amount numeric(18,2),
    sales_tax_payment_amount numeric(18,2),
    sales_tax_refund_amount numeric(18,2),
    seller_discount_amount numeric(18,2),
    seller_discount_refund_amount numeric(18,2),
    settlement_amount numeric(18,2),
    shipping_cost_amount numeric(18,2),
    shipping_cost_discount_amount numeric(18,2),
    shipping_fee_amount numeric(18,2),
    shipping_fee_subsidy_amount numeric(18,2),
    shipping_insurance_fee_amount numeric(18,2),
    signature_confirmation_fee_amount numeric(18,2),
    transaction_fee_amount numeric(18,2),
    raw jsonb NOT NULL,
    synced_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.statement_transactions OWNER TO postgres;

--
-- Name: statements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.statements (
    statement_id text NOT NULL,
    shop_id text,
    payment_id text,
    currency text,
    payment_status text,
    statement_time bigint,
    payment_time bigint,
    revenue_amount numeric(18,2),
    fee_amount numeric(18,2),
    net_sales_amount numeric(18,2),
    shipping_cost_amount numeric(18,2),
    adjustment_amount numeric(18,2),
    settlement_amount numeric(18,2),
    raw jsonb NOT NULL,
    synced_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.statements OWNER TO postgres;

--
-- Name: sync_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sync_log (
    id bigint NOT NULL,
    shop_id text,
    sync_type text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    rows_affected integer,
    status text,
    error_message text
);


ALTER TABLE public.sync_log OWNER TO postgres;

--
-- Name: oauth_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_tokens ALTER COLUMN id SET DEFAULT nextval('public.oauth_tokens_id_seq'::regclass);


--
-- Data for Name: analytics_audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_audit_log (id, request_id, endpoint, method, path, status, key_prefix, records_in, records_ok, records_rej, error_code, created_at) FROM stdin;
\.


--
-- Data for Name: analytics_cursors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_cursors (seller_id, advertiser_id, storage_key, campaign_id, latest_completed_day, last_updated_at, request_id) FROM stdin;
\.


--
-- Data for Name: analytics_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_records (id, idempotency_key, source_record_id, seller_id, advertiser_id, storage_key, campaign_id, day, page, shop_name, endpoint, method, request_body, response_data, source, captured_at, schema_version, protocol_version, received_at, request_id) FROM stdin;
\.


--
-- Data for Name: analytics_shop_timezones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_shop_timezones (seller_id, advertiser_id, timezone, updated_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_keys (id, key_hash, key_prefix, name, role, enabled, created_at, last_used_at, expires_at, scopes) FROM stdin;
\.


--
-- Data for Name: cancellations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cancellations (cancel_id, shop_id, order_id, cancel_status, cancel_reason, cancel_reason_text, cancel_type, role, should_replenish_stock, create_time, update_time, raw, synced_at) FROM stdin;
\.


--
-- Data for Name: logistics_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logistics_events (id, order_id, action_code, event_time, location, description, raw, created_at) FROM stdin;
\.


--
-- Data for Name: logistics_sync_targets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logistics_sync_targets (order_id, shop_id, last_synced_at, last_n_events, needs_resync) FROM stdin;
\.


--
-- Data for Name: logistics_tracking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logistics_tracking (order_id, shop_id, tracking_number, n_events, first_event_at, last_event_at, last_action_code, last_description, final_status, arrived_overseas, arrived_at, origin_departed_at, import_cleared_at, delivered_at, returned_at, raw, synced_at) FROM stdin;
\.


--
-- Data for Name: logistics_tracking_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logistics_tracking_events (order_id, action_code, event_time, description, location, synced_at) FROM stdin;
\.


--
-- Data for Name: miaoshou_collect_box_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.miaoshou_collect_box_details (platform, common_collect_box_detail_id, app_account_id, sub_app_account_id, item_num, title, thumbnail, list_thumbnail, price, min_sku_price, max_sku_price, stock, remark, status, reason, gmt_create, gmt_modified, weight, max_sku_weight, min_sku_weight, common_collect_box_group_id, common_collect_box_group_name, owner_sub_account_alias_name, is_mark, is_cb, is_cnsc, raw_json, synced_at) FROM stdin;
\.


--
-- Data for Name: miaoshou_move_collect_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.miaoshou_move_collect_tasks (platform, move_collect_task_detail_id, collect_box_detail_id, shop_id, item_num, cid, source, source_site, source_item_id, title, thumbnail, is_timing, status, reason, gmt_create, gmt_modified, platform_item_id, is_renew_item, shop_name, site_name, site, source_item_url, item_edit_url, breadcrumb, owner_sub_app_account_id, owner_sub_account_alias_name, raw_json, synced_at) FROM stdin;
\.


--
-- Data for Name: miaoshou_price_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.miaoshou_price_templates (price_template_id, app_account_id, sub_app_account_id, platform, site, name, remark, currency, display_weight_unit, profit_type, profit_percent, fixed_profit_amount, exchange_rate, discount, price_tail_compute_type, price_tail, price_process_decimal_type, logistics_compute_type, weight_ref_type, first_weight_charge, first_weight_interval, continued_weight_charge, continued_weight_interval, logistics_charge, platform_charge_percent, payment_charge_percent, activity_charge_percent, withdraw_charge_percent, other_charge, is_cal_light_cargo, light_cargo_coefficient, weight_logistics_charge_list, domestic_logistics_compute_type, domestic_logistics_first_weight_charge, domestic_logistics_first_weight_interval, domestic_logistics_continued_weight_charge, domestic_logistics_continued_weight_interval, domestic_logistics_charge, buyer_logistic_charge, seller_logistic_charge, has_seller_logistic_charge, official_tpl_mode, official_tpl_logistics_channel, snapshot_id, gmt_create, gmt_modified, raw_json, synced_at) FROM stdin;
\.


--
-- Data for Name: miaoshou_shops; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.miaoshou_shops (shop_id, platform, site, platform_shop_name, shop_nick, parent_shop_id, is_cb, is_cnsc, status, gmt_expire, gmt_last_auth, raw_json, synced_at) FROM stdin;
\.


--
-- Data for Name: oauth_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_tokens (id, shop_id, provider, access_token_encrypted, refresh_token_encrypted, shop_cipher_encrypted, shop_name, shop_region, seller_type, access_token_expires_at, refresh_token_expires_at, granted_scopes, created_at, updated_at, last_used_at, last_refresh_at) FROM stdin;
18	MOCK_SHOP_12345	tiktok	\\x67414141414142716a374252326548587459504e5969687a57587246484256334d6b37556642685a372d6e5f5f514f7a324b3668664b5f303758753039352d346a6f563853584f6530787273795036654a4543646e623639393435617443634467357166656a77424944496d77305258344f42656739746e6b48357a326835703863627435672d326f757372	\\x67414141414142716a3742527548495f79446444687273426871695f42425f5a42555047482d4f5561516368334a496a564d315a36583266467658315a2d4e5239667a63394748544931644b785945624c543855624d355770454879594d6b7a336e78553765395a414b54517567775871715330536a31474a5a657a324570484b4c424c5a304a32766a5444	\\x67414141414142716a37425238537844726a387059634e4447307436433050335173694d30424a436d304951725557366137494c4862774b6e314e354c4962724143706170393069317453487954752d75433770774847567a34777431594c51574d4652454431713839413174444c33544336386e4b4a56646342344b6e7439395837752d4f494150554a75	MOCK Test Shop	US	CROSS_BORDER	1788406481	1819337681	{user_info,orders,products}	2026-08-24 06:41:50.121837+00	2026-08-27 03:34:41.085343+00	\N	2026-08-27 03:34:41.085343+00
1	7494763368967603447	tiktok	\\x67414141414142716a73786d42425373317232485f6a6c626c5677535f493659396275346470733478736969344c43426a74425368392d4670536f4e68663253573472307644754232686e64415556645359413665594b3251584d4f674e356c57424269792d6d5945364e712d69677a42454b45576b4442354d52517652446b4d41424e647361784d57634b4a33387847693561626f394630505553434d30397370723458346f674c45533573444e703362625a4862554159564e55565842576b47446c3837685a52746a5043777475395f784268436f70583074336b77794461746378714b77467630695a6638734a534c754d7570446f6852776b584554767a6b434d63672d336341486c4575467a43766835796352785f6e676c6b58567276356b3779786a63316b6f42534d4549657268583953453d	\\x67414141414142716a73786d61384d6e7663666b4e6f725666666e7a61414c37304e4d5269346a486646457338326a4e3055313678497154656b632d49696832644546784e7664386b396a354f74307841383066504f4a527479376d58437a5a7771503279446e766b413270513130736543496243326b65464e354d31624a55456a5772526a3338766c7672312d354333474443412d6e4a5130646c62524c4e7536454f366374744b456b6b39736364344f42454c51673d	\\x67414141414142716a73786d69486a3541634a6f58516d716a552d644962527338585a63644a4745762d59456d5857704f4631563661704e37516a616e6655313251585465526d6d4479552d305a6f5979706732627334777239616336557473423063694d6c4d6c537358527972315a644748756971646b554d64652d6b635953732d77524e543162464141	Bridge nook	VN	CROSS_BORDER	1788154752	4908920456	{data.bestselling.public.read,seller.global_product.category.info,seller.shop.info,seller.logistics,seller.product.basic,data.shop_analytics.public.read,seller.finance.info,seller.fulfillment.basic,seller.global_product.info,seller.order.info,seller.promotion.info,seller.return_refund.basic,seller.authorization.info}	2026-08-16 09:37:09.32665+00	2026-08-26 11:22:14.610002+00	\N	2026-08-26 11:22:14.610002+00
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (order_id, item_id, shop_id, sku_id, product_id, product_name, sku_name, sku_image, quantity, sku_price, raw) FROM stdin;
\.


--
-- Data for Name: order_shippings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_shippings (order_id, shop_id, tracking_number, shipping_provider_id, shipping_provider_name, raw, synced_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (order_id, shop_id, order_status_name, payment_amount, payment_currency, total_amount, buyer_email, buyer_message, create_time, update_time, paid_time, shipped_time, delivered_time, cancelled_time, fulfillment_type, raw, synced_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (payment_id, shop_id, status, currency, amount_value, settlement_amount_value, payment_amount_before_value, reserve_amount_value, exchange_rate, bank_account, create_time, paid_time, raw, synced_at) FROM stdin;
\.


--
-- Data for Name: returns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.returns (return_id, shop_id, order_id, return_status, return_reason, return_type, role, create_time, update_time, raw, synced_at) FROM stdin;
\.


--
-- Data for Name: shops; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shops (shop_id, shop_name, shop_region, shop_cipher, seller_type, last_seen_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: statement_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.statement_transactions (txn_id, statement_id, shop_id, order_id, order_create_time, type, currency, actual_return_shipping_fee_amount, actual_shipping_fee_amount, adjustment_amount, affiliate_ads_commission_amount, affiliate_commission_amount, affiliate_commission_before_pit, affiliate_partner_commission_amount, after_seller_discounts_subtotal_amount, customer_order_refund_amount, customer_paid_shipping_fee_amount, customer_paid_shipping_fee_refund_amount, customer_payment_amount, customer_refund_amount, customer_shipping_fee_amount, customer_shipping_fee_offset_amount, fbm_shipping_cost_amount, fbt_fulfillment_fee_amount, fbt_fulfillment_fee_reimbursement_amount, fbt_shipping_cost_amount, fee_amount, gross_sales_amount, gross_sales_refund_amount, isr_income_tax_amount, iva_vat_amount, net_sales_amount, pit_amount, platform_commission_amount, platform_discount_amount, platform_discount_refund_amount, platform_refund_subsidy_amount, platform_shipping_fee_discount_amount, promo_shipping_incentive_amount, referral_fee_amount, refund_administration_fee_amount, refund_shipping_cost_discount_amount, retail_delivery_fee_amount, retail_delivery_fee_payment_amount, retail_delivery_fee_refund_amount, return_shipping_fee_amount, revenue_amount, sales_tax_amount, sales_tax_payment_amount, sales_tax_refund_amount, seller_discount_amount, seller_discount_refund_amount, settlement_amount, shipping_cost_amount, shipping_cost_discount_amount, shipping_fee_amount, shipping_fee_subsidy_amount, shipping_insurance_fee_amount, signature_confirmation_fee_amount, transaction_fee_amount, raw, synced_at) FROM stdin;
\.


--
-- Data for Name: statements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.statements (statement_id, shop_id, payment_id, currency, payment_status, statement_time, payment_time, revenue_amount, fee_amount, net_sales_amount, shipping_cost_amount, adjustment_amount, settlement_amount, raw, synced_at) FROM stdin;
\.


--
-- Data for Name: sync_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sync_log (id, shop_id, sync_type, started_at, finished_at, rows_affected, status, error_message) FROM stdin;
\.


--
-- Name: oauth_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_tokens_id_seq', 2464, true);


--
-- Name: analytics_audit_log analytics_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_audit_log
    ADD CONSTRAINT analytics_audit_log_pkey PRIMARY KEY (id);


--
-- Name: analytics_cursors analytics_cursors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_cursors
    ADD CONSTRAINT analytics_cursors_pkey PRIMARY KEY (seller_id, advertiser_id, storage_key, campaign_id);


--
-- Name: analytics_records analytics_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_records
    ADD CONSTRAINT analytics_records_pkey PRIMARY KEY (id);


--
-- Name: analytics_shop_timezones analytics_shop_timezones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_shop_timezones
    ADD CONSTRAINT analytics_shop_timezones_pkey PRIMARY KEY (seller_id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: cancellations cancellations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cancellations
    ADD CONSTRAINT cancellations_pkey PRIMARY KEY (cancel_id);


--
-- Name: logistics_events logistics_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logistics_events
    ADD CONSTRAINT logistics_events_pkey PRIMARY KEY (id);


--
-- Name: logistics_sync_targets logistics_sync_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logistics_sync_targets
    ADD CONSTRAINT logistics_sync_targets_pkey PRIMARY KEY (order_id);


--
-- Name: logistics_tracking_events logistics_tracking_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logistics_tracking_events
    ADD CONSTRAINT logistics_tracking_events_pkey PRIMARY KEY (order_id, action_code, event_time);


--
-- Name: logistics_tracking logistics_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logistics_tracking
    ADD CONSTRAINT logistics_tracking_pkey PRIMARY KEY (order_id);


--
-- Name: miaoshou_collect_box_details miaoshou_collect_box_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.miaoshou_collect_box_details
    ADD CONSTRAINT miaoshou_collect_box_details_pkey PRIMARY KEY (platform, common_collect_box_detail_id);


--
-- Name: miaoshou_move_collect_tasks miaoshou_move_collect_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.miaoshou_move_collect_tasks
    ADD CONSTRAINT miaoshou_move_collect_tasks_pkey PRIMARY KEY (platform, move_collect_task_detail_id);


--
-- Name: miaoshou_price_templates miaoshou_price_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.miaoshou_price_templates
    ADD CONSTRAINT miaoshou_price_templates_pkey PRIMARY KEY (price_template_id);


--
-- Name: miaoshou_shops miaoshou_shops_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.miaoshou_shops
    ADD CONSTRAINT miaoshou_shops_pkey PRIMARY KEY (platform, site, shop_id);


--
-- Name: oauth_tokens oauth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_tokens
    ADD CONSTRAINT oauth_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_tokens oauth_tokens_shop_provider_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_tokens
    ADD CONSTRAINT oauth_tokens_shop_provider_unique UNIQUE (shop_id, provider);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (order_id, item_id);


--
-- Name: order_shippings order_shippings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_shippings
    ADD CONSTRAINT order_shippings_pkey PRIMARY KEY (order_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (payment_id);


--
-- Name: returns returns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.returns
    ADD CONSTRAINT returns_pkey PRIMARY KEY (return_id);


--
-- Name: shops shops_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shops
    ADD CONSTRAINT shops_pkey PRIMARY KEY (shop_id);


--
-- Name: statement_transactions statement_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statement_transactions
    ADD CONSTRAINT statement_transactions_pkey PRIMARY KEY (txn_id);


--
-- Name: statements statements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statements
    ADD CONSTRAINT statements_pkey PRIMARY KEY (statement_id);


--
-- Name: sync_log sync_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sync_log
    ADD CONSTRAINT sync_log_pkey PRIMARY KEY (id);


--
-- Name: analytics_records uq_analytics_records_idem; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_records
    ADD CONSTRAINT uq_analytics_records_idem UNIQUE (idempotency_key);


--
-- Name: api_keys uq_api_keys_prefix; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT uq_api_keys_prefix UNIQUE (key_prefix);


--
-- Name: idx_analytics_audit_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_audit_created ON public.analytics_audit_log USING btree (created_at DESC);


--
-- Name: idx_analytics_audit_request; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_audit_request ON public.analytics_audit_log USING btree (request_id);


--
-- Name: idx_analytics_records_received; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_records_received ON public.analytics_records USING btree (received_at DESC);


--
-- Name: idx_analytics_records_request; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_records_request ON public.analytics_records USING btree (request_id);


--
-- Name: idx_analytics_records_scope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_analytics_records_scope ON public.analytics_records USING btree (seller_id, advertiser_id, storage_key, campaign_id, day);


--
-- Name: idx_cancellations_create_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cancellations_create_time ON public.cancellations USING btree (create_time DESC);


--
-- Name: idx_cancellations_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cancellations_order ON public.cancellations USING btree (order_id);


--
-- Name: idx_cancellations_shop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cancellations_shop ON public.cancellations USING btree (shop_id);


--
-- Name: idx_cancellations_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cancellations_status ON public.cancellations USING btree (cancel_status);


--
-- Name: idx_logistics_events_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_logistics_events_order ON public.logistics_events USING btree (order_id, event_time DESC);


--
-- Name: idx_logistics_tracking_final; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_logistics_tracking_final ON public.logistics_tracking USING btree (final_status);


--
-- Name: idx_logistics_tracking_final_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_logistics_tracking_final_status ON public.logistics_tracking USING btree (final_status);


--
-- Name: idx_logistics_tracking_last_event; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_logistics_tracking_last_event ON public.logistics_tracking USING btree (last_event_at DESC);


--
-- Name: idx_logistics_tracking_overseas; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_logistics_tracking_overseas ON public.logistics_tracking USING btree (arrived_overseas);


--
-- Name: idx_logistics_tracking_shop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_logistics_tracking_shop ON public.logistics_tracking USING btree (shop_id);


--
-- Name: idx_logistics_tracking_tracking; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_logistics_tracking_tracking ON public.logistics_tracking USING btree (tracking_number);


--
-- Name: idx_logistics_tracking_tracking_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_logistics_tracking_tracking_number ON public.logistics_tracking USING btree (tracking_number);


--
-- Name: idx_lt_events_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lt_events_action ON public.logistics_tracking_events USING btree (action_code);


--
-- Name: idx_lt_events_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lt_events_order ON public.logistics_tracking_events USING btree (order_id);


--
-- Name: idx_lt_events_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lt_events_time ON public.logistics_tracking_events USING btree (event_time DESC);


--
-- Name: idx_lt_targets_resync; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lt_targets_resync ON public.logistics_sync_targets USING btree (needs_resync) WHERE (needs_resync = true);


--
-- Name: idx_lt_targets_shop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_lt_targets_shop ON public.logistics_sync_targets USING btree (shop_id);


--
-- Name: idx_miaoshou_collect_box_platform_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_miaoshou_collect_box_platform_status ON public.miaoshou_collect_box_details USING btree (platform, status);


--
-- Name: idx_miaoshou_move_collect_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_miaoshou_move_collect_status ON public.miaoshou_move_collect_tasks USING btree (platform, status);


--
-- Name: idx_miaoshou_move_collect_synced; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_miaoshou_move_collect_synced ON public.miaoshou_move_collect_tasks USING btree (synced_at DESC);


--
-- Name: idx_miaoshou_shops_platform_site; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_miaoshou_shops_platform_site ON public.miaoshou_shops USING btree (platform, site);


--
-- Name: idx_miaoshou_shops_synced_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_miaoshou_shops_synced_at ON public.miaoshou_shops USING btree (synced_at DESC);


--
-- Name: idx_oauth_tokens_expires; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_oauth_tokens_expires ON public.oauth_tokens USING btree (access_token_expires_at);


--
-- Name: idx_oauth_tokens_provider; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_oauth_tokens_provider ON public.oauth_tokens USING btree (provider);


--
-- Name: idx_order_items_shop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_order_items_shop ON public.order_items USING btree (shop_id);


--
-- Name: idx_orders_create_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_create_time ON public.orders USING btree (create_time DESC);


--
-- Name: idx_orders_shop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_shop ON public.orders USING btree (shop_id);


--
-- Name: idx_payments_paid_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_paid_time ON public.payments USING btree (paid_time DESC);


--
-- Name: idx_payments_shop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_shop ON public.payments USING btree (shop_id);


--
-- Name: idx_payments_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_status ON public.payments USING btree (status);


--
-- Name: idx_returns_create_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_returns_create_time ON public.returns USING btree (create_time DESC);


--
-- Name: idx_returns_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_returns_order ON public.returns USING btree (order_id);


--
-- Name: idx_returns_shop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_returns_shop ON public.returns USING btree (shop_id);


--
-- Name: idx_returns_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_returns_status ON public.returns USING btree (return_status);


--
-- Name: idx_statements_payment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_statements_payment_id ON public.statements USING btree (payment_id);


--
-- Name: idx_statements_shop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_statements_shop ON public.statements USING btree (shop_id);


--
-- Name: idx_statements_stime; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_statements_stime ON public.statements USING btree (statement_time DESC);


--
-- Name: idx_stmt_txns_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stmt_txns_order ON public.statement_transactions USING btree (order_id);


--
-- Name: idx_stmt_txns_shop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stmt_txns_shop ON public.statement_transactions USING btree (shop_id);


--
-- Name: idx_stmt_txns_stmt; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stmt_txns_stmt ON public.statement_transactions USING btree (statement_id);


--
-- Name: idx_sync_log_shop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sync_log_shop ON public.sync_log USING btree (shop_id, started_at DESC);


--
-- Name: oauth_tokens trg_oauth_tokens_touch; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_oauth_tokens_touch BEFORE UPDATE ON public.oauth_tokens FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: orders trg_orders_touch; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_orders_touch BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: shops trg_shops_touch; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_shops_touch BEFORE UPDATE ON public.shops FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: sync_log trg_sync_log_retention; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_sync_log_retention AFTER INSERT ON public.sync_log FOR EACH STATEMENT EXECUTE FUNCTION public.trg_sync_log_retention_fn();


--
-- Name: logistics_events logistics_events_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logistics_events
    ADD CONSTRAINT logistics_events_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(order_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict C3hadsvVZSKudQvxIFAJOJ68ROA3t3F671NJWCAQrD5OordqMIWuJIISkNy9Xmv

